# SmartGuide-CarRental

App with react native, to getting start with that framework.

### Prerequisites

Only you need to execute is this command:
```
npm install
```

### About tests

The tests don't works properly, I have left the code that I tried, but is more like pseudocode for know what I had in mind. 
